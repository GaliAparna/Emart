export class Buyer {
}
